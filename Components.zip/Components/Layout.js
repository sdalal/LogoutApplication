import React, { Component } from 'react';
import { Container } from 'reactstrap';
import { Link } from 'react-router-dom';
import Header from './Header';


export class Layout extends Component {
  static displayName = Layout.name;

  render () {
    return (
        <div>
            <Header />
            <div align="right"> <Link to="/logout">Logout</Link></div>
            <hr />
        <Container>
          {this.props.children}
                </Container>
      </div>
    );
  }
}
