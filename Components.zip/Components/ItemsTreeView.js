﻿import React, { Component } from 'react';

class ItemsTreeView extends Component {
    render() {
        return (
            <div id="TreeView">
                Display Items Data here
            </div>
        );
    }
}

export default ItemsTreeView;


