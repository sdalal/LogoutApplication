﻿import React, { Component } from 'react';

class ProductsTreeView extends Component {
    render() {
        return (
            <div id="TreeView">
                Display Products Data here
            </div>
        );
    }
}

export default ProductsTreeView;


