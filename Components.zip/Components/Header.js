﻿import React from "react";
import './AdminStyle.css';

export class Header extends React.Component {
    static displayName = Header.name;

    constructor(props) {
        super(props);

     }

       render() {
          return (
               <div>   
   
                   <table className="tableHeader">
                       <tbody>
                       <tr className="trheader">
                           <td className="tdheader">
                           Welcome to my website
                        </td>
                           <td className="tdheader" align="right">
                              <label className="Label" name="lblUserName" >Welcome: testing</label><br />
                              <label className="Label" name="lblLastVisisted">date</label>
            
</td>
                        </tr >
                        </tbody>
                     </table >
           
            
            </div>
        );
    }
}

export default Header;

