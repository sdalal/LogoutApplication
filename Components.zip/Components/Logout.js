﻿import React, { Component } from 'react'
import { Route, Link } from 'react-router-dom';
import "./AdminStyle.css";

export class Logout extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (

            <div id="container">
                <p CssClass="Label" Font-Size="Small"><b>You have been logged out.</b></p><br /><br />
                <p>Sign back in. Please <Link to="/">return to Homepage.</Link></p>
            </div>

        );
    };
}

export default Logout;